# Agent Instructions - .NET MAUI K12 Project

## Mode

Read `.agents/MAUI-Agent-Mode.json` before every session.

Current default:

```text
studentCapabilityMode: true
```

State the current mode as the first line of every work response:

```text
Mode: MAXIMIZE STUDENT CAPABILITY
```

or:

```text
Mode: MAXIMIZE CODE GENERATED
```

Never change the mode silently.

## Required Skill

Read `.agents/skills/maui-k12-baton-workflow/SKILL.md` at the start of every session in this project.

Use it for any feature, screen, refactor, code review, test work, or learning documentation in this .NET MAUI student project.

## Student Capability Mode Rules

When `studentCapabilityMode=true`, never dump planning, concept explanations, implementation tasks, and verification instructions in one response.

Use the baton workflow:

```text
PLANNING_COACH
  -> PLAN_CONFIRMATION
  -> CONCEPT_TUTOR
  -> OWNERSHIP_NEGOTIATOR
  -> EXECUTION_AGENT
  -> VERIFICATION_AUDITOR
```

## Non-Negotiable Rules

- Planning comes before coding.
- Concept gate comes before implementation tasks.
- Ownership choice comes before execution.
- The default is agent scaffolding plus a meaningful `// TODO (Student): ...`.
- The student may explicitly choose agent-does-all only after the plan and concept gates.
- Stop at every waiting status until the student responds.
- Never use `Page.IsBusy`; use ViewModel `IsLoading` and `ActivityIndicator`.
- Never use `SetProperty(ref _field, value)` until the student demonstrates `ref` understanding.
- Keep learning documentation in Hebrew when the student works in Hebrew.
- Run build/tests/validation before declaring PASS.

## Expected Project Structure

```text
<AppName>/          main MAUI app project
<AppName>.Tests/    xUnit test project
.agents/            agent config and skills
Scripts/            optional validation scripts
Learning/           student learning artifacts
Docs/               project documentation
```

## Useful Commands

```powershell
dotnet build
dotnet test
.\Scripts\Validate-Maui-Version.ps1
.\Scripts\Validate-Maui-ObsoleteApis.ps1
.\Scripts\Validate-Maui-XamlResources.ps1
.\Scripts\Audit-DI.ps1
```

If a script is missing, continue with the closest manual check and state the limitation.
