# MAUI Learning Book

This is the student's append-only learning book.

Each meaningful code change should add a compact lesson that explains:
- what changed
- why it changed
- what MAUI/C# concept was learned
- how to verify the work
- one or two check questions

If the student works in Hebrew, write explanations in Hebrew while keeping C# and XAML identifiers in English.
