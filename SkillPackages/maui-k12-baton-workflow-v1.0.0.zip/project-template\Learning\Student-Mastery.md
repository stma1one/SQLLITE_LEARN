# Student Mastery Tracker

Use these levels:

```text
Not introduced
Practicing
Understands
Can work independently
```

## Concepts

```text
Models: Not introduced
Properties: Not introduced
INotifyPropertyChanged: Not introduced
ObservableCollection: Not introduced
XAML binding: Not introduced
Commands: Not introduced
CanExecute: Not introduced
async/await: Not introduced
DI: Not introduced
Shell navigation: Not introduced
validation: Not introduced
testing: Not introduced
```
